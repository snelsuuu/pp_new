# ROS2 node (phase 3 — pending)

Will wrap `planner.improved_plan_v2` in a thin rclpy node:
subscribe /slam/odom + /slam/map_cones, call the planner each tick,
publish nav_msgs/Path. The pure-python core stays ROS-free so it
remains unit-testable and benchmarkable offline.
