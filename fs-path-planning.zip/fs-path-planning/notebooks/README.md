Place exploration notebooks here (e.g. 01_baseline_and_benchmark.ipynb).
Prefer importing from `planner` and `sim` rather than redefining
functions in cells.
